sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("appui.sdorders.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map